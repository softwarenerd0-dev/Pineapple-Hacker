# Pineapple Hacker — Data Lab update

This update preserves the original neon terminal and adds real local data operations:
- `.database search <keyword>` searches fictional in-page records.
- `.records` lists the sample records.
- `.access DEMO-002` opens a fictional sample record.
- `.audit` reports what the sandbox actually did.
- `.hash <text>` computes a SHA-256 digest with browser Web Crypto.
- `.encode <text>` and `.decode <base64>` encode/decode Base64.
- `.json <json>` parses and pretty-prints JSON.

**Access boundary:** all records are fictional and local to this page. No private people, accounts, external databases, or other systems are accessed. This remains a static browser page; it does not deploy a Cloudflare Worker or connect Cloudflare D1.

## Cloudflare Pages
Put `index.html` at the root of a static site or GitHub repository connected to Cloudflare Pages. Real D1, AI, weather API, and protected owner authentication require separate server-side configuration.
